import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PoApprovalsBrowserComponent } from './po-approvals-browser.component';

describe('PoApprovalsBrowserComponent', () => {
  let component: PoApprovalsBrowserComponent;
  let fixture: ComponentFixture<PoApprovalsBrowserComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PoApprovalsBrowserComponent]
    });
    fixture = TestBed.createComponent(PoApprovalsBrowserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
