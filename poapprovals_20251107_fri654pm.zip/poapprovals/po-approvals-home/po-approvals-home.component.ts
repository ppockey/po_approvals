import { Component } from '@angular/core';

@Component({
  selector: 'itt-po-approvals-home',
  templateUrl: './po-approvals-home.component.html',
  styleUrls: ['./po-approvals-home.component.css']
})
export class PoApprovalsHomeComponent {

}
