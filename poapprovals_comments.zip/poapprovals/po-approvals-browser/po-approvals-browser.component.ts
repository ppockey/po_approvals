import { Component, ViewChild } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { DialogComponent } from '@syncfusion/ej2-angular-popups';
import { toDataSourceRequest } from '@progress/kendo-data-query';
// import { DataResult } from '@syncfusion/ej2-angular-grids';

/** Models */
type PoHeaderView = {
  poNumber: string;
  poDate?: string;
  vendorName?: string;
  buyerName?: string;
  houseCode?: string;
  directAmount?: number;
  indirectAmount?: number;
  totalAmount: number;
  status: 'W' | 'A' | 'D';
  isActive: boolean;
  createdAtUtc?: string;
  activeLineCount: number;
};

type PoLineView = {
  poNumber: string;
  lineNumber: number;
  itemNumber: string;
  itemDescription?: string;
  specialDescription?: string;
  quantityOrdered?: number;
  orderUom?: string;
  unitCost?: number;
  extendedCost?: number;
  requiredDate?: string;
  glAccount?: string;
  isActive: boolean;
};

type PoStage = {
  poNumber: string;
  sequence: number;
  roleCode: string;
  approverUserId?: string;
  category?: 'I' | 'D' | null;
  thresholdFrom?: number;
  thresholdTo?: number;
  status: 'P' | 'A' | 'D' | 'S';
  decidedAtUtc?: string;
};

type PoListResponse = {
  total: number;
  page: number;
  pageSize: number;
  rows: any[];
};
type PoDetailResponse = {
  header: any;
  lines: any[];
  stages: any[];
  audit: any[];
};

@Component({
  selector: 'app-po-approvals-browser',
  templateUrl: './po-approvals-browser.component.html',
  styleUrls: ['./po-approvals-browser.component.css'],
})
export class PoApprovalsBrowserComponent {
  /** Master grid data */
  // data: DataResult = { result: [], count: 0 };
  poRows: PoHeaderView[] = [];

  /** Dialog state */
  detailHeader: PoHeaderView | null = null;
  lines: PoLineView[] = [];
  stages: PoStage[] = [];
  dialogOpen = false;

  @ViewChild('poDialog', { static: false }) poDialog?: DialogComponent;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    const params = new HttpParams().set('page', '1').set('pageSize', '20');
    this.http.get<PoListResponse>('/api/po', { params }).subscribe((resp) => {
      const rows = (resp?.rows ?? []).map(this.toHeader);
      // this.data = { result: rows, count: resp?.total ?? rows.length };
      this.poRows = rows;
    });
  }

  // ---------- Normalizers ------------

  private toHeader = (h: any): PoHeaderView => ({
    poNumber: h.poNumber ?? h.PoNumber ?? '',
    poDate: h.poDate ?? h.PoDate,
    vendorName: h.vendorName ?? h.VendorName,
    buyerName: h.buyerName ?? h.BuyerName,
    houseCode: h.houseCode ?? h.HouseCode,
    directAmount: h.directAmount ?? h.DirectAmount ?? 0,
    indirectAmount: h.indirectAmount ?? h.IndirectAmount ?? 0,
    totalAmount:
      h.totalAmount ??
      h.TotalAmount ??
      (h.directAmount ?? h.DirectAmount ?? 0) +
        (h.indirectAmount ?? h.IndirectAmount ?? 0),
    status: (h.status ?? h.Status ?? 'W') as 'W' | 'A' | 'D',
    isActive: (h.isActive ?? h.IsActive ?? true) as boolean,
    createdAtUtc: h.createdAtUtc ?? h.CreatedAtUtc,
    activeLineCount: h.activeLineCount ?? h.ActiveLineCount ?? 0,
  });

  private toLine = (l: any): PoLineView => ({
    poNumber: l.poNumber ?? l.PoNumber ?? '',
    lineNumber: l.lineNumber ?? l.LineNumber ?? 0,
    itemNumber: l.itemNumber ?? l.ItemNumber ?? '',
    itemDescription: l.itemDescription ?? l.ItemDescription,
    specialDescription: l.specialDescription ?? l.SpecialDescription,
    quantityOrdered: l.quantityOrdered ?? l.QuantityOrdered,
    orderUom: l.orderUom ?? l.OrderUom,
    unitCost: l.unitCost ?? l.UnitCost,
    extendedCost: l.extendedCost ?? l.ExtendedCost,
    requiredDate: l.requiredDate ?? l.RequiredDate,
    glAccount: l.glAccount ?? l.GlAccount,
    isActive: (l.isActive ?? l.IsActive ?? true) as boolean,
  });

  private toStage = (s: any): PoStage => ({
    poNumber: s.poNumber ?? s.PoNumber ?? '',
    sequence: s.sequence ?? s.Sequence ?? 0,
    roleCode: s.roleCode ?? s.RoleCode ?? '',
    approverUserId: s.approverUserId ?? s.ApproverUserId,
    category: (s.category ?? s.Category ?? null) as 'I' | 'D' | null,
    thresholdFrom: s.thresholdFrom ?? s.ThresholdFrom,
    thresholdTo: s.thresholdTo ?? s.ThresholdTo,
    status: (s.status ?? s.Status ?? 'P') as 'P' | 'A' | 'D' | 'S',
    decidedAtUtc: s.decidedAtUtc ?? s.DecidedAtUtc,
  });

  // ----------------------- Events ------------------------------------------

  onRowSelected(e: any) {
    const row = e?.data;
    const poNumber: string = row?.poNumber ?? row?.PoNumber ?? '';
    if (!poNumber) return;

    this.http
      .get<PoDetailResponse>(`/api/po/${encodeURIComponent(poNumber)}`)
      .subscribe((d) => {
        this.detailHeader = this.toHeader(d?.header ?? row);
        this.lines = (d?.lines ?? []).map(this.toLine);
        this.stages = (d?.stages ?? []).map(this.toStage);
        this.poDialog?.show();
      });
  }

  // onRowClicked(e: any) {
  //   const row = e?.data ?? e?.rowData;
  //   if (!row) return;
  //   this.onRowSelected({ data: row });
  // }

  // onRowSelecting(args: any) {
  //   args.cancel = true;
  // }

  // ----------------------- Page scroll lock (no styles.scss changes) -------

  private scrollY = 0;
  private bodyStyleBackup: Partial<CSSStyleDeclaration> = {};
  private lockDepth = 0; // guard for nested opens

  private freezePageScroll(): void {
    if (this.lockDepth++ > 0) return; // already locked

    if (typeof window === 'undefined' || typeof document === 'undefined')
      return;

    this.scrollY = window.scrollY || window.pageYOffset || 0;
    const b = document.body;

    // backup inline styles to restore later
    this.bodyStyleBackup = {
      position: b.style.position,
      overflow: b.style.overflow,
      width: b.style.width,
      top: b.style.top,
      left: b.style.left,
      right: b.style.right,
    };

    // lock page without layout jump
    b.style.position = 'fixed';
    b.style.overflow = 'hidden';
    b.style.width = '100%';
    b.style.top = `-${this.scrollY}px`;
    b.style.left = '0';
    b.style.right = '0';
  }

  private unfreezePageScroll(): void {
    if (--this.lockDepth > 0) return; // another dialog still open

    if (typeof window === 'undefined' || typeof document === 'undefined')
      return;

    const b = document.body;

    // restore inline styles exactly
    b.style.position = this.bodyStyleBackup.position ?? '';
    b.style.overflow = this.bodyStyleBackup.overflow ?? '';
    b.style.width = this.bodyStyleBackup.width ?? '';
    b.style.top = this.bodyStyleBackup.top ?? '';
    b.style.left = this.bodyStyleBackup.left ?? '';
    b.style.right = this.bodyStyleBackup.right ?? '';

    // restore scroll position
    window.scrollTo(0, this.scrollY);
  }

  onDlgOpen() {
    this.dialogOpen = true;
    this.freezePageScroll();
  }

  onDlgClose() {
    this.dialogOpen = false;
    this.unfreezePageScroll();
  }

  // Placeholders (wire later)
  approve() {alert("You clicked the Approved button.")}
  deny() {alert("You clicked the Deny button.")}
}

// import { Component, ViewChild } from '@angular/core';
// import { HttpClient, HttpParams } from '@angular/common/http';
// import { DialogComponent } from '@syncfusion/ej2-angular-popups';
// // import { DataResult } from '@syncfusion/ej2-angular-grids';

// /** Models */
// type PoHeaderView = {
//   poNumber: string;
//   poDate?: string;
//   vendorName?: string;
//   buyerName?: string;
//   houseCode?: string;
//   directAmount?: number;
//   indirectAmount?: number;
//   totalAmount: number;
//   status: 'W' | 'A' | 'D';
//   isActive: boolean;
//   createdAtUtc?: string;
//   activeLineCount: number;
// };

// type PoLineView = {
//   poNumber: string;
//   lineNumber: number;
//   itemNumber: string;
//   itemDescription?: string;
//   specialDescription?: string;
//   quantityOrdered?: number;
//   orderUom?: string;
//   unitCost?: number;
//   extendedCost?: number;
//   requiredDate?: string;
//   glAccount?: string;
//   isActive: boolean;
// };

// type PoStage = {
//   poNumber: string;
//   sequence: number;
//   roleCode: string;
//   approverUserId?: string;
//   category?: 'I' | 'D' | null;
//   thresholdFrom?: number;
//   thresholdTo?: number;
//   status: 'P' | 'A' | 'D' | 'S';
//   decidedAtUtc?: string;
// };

// type PoListResponse = {
//   total: number;
//   page: number;
//   pageSize: number;
//   rows: any[];
// };
// type PoDetailResponse = {
//   header: any;
//   lines: any[];
//   stages: any[];
//   audit: any[];
// };

// @Component({
//   selector: 'app-po-approvals-browser',
//   templateUrl: './po-approvals-browser.component.html',
//   styleUrls: ['./po-approvals-browser.component.css'],
// })
// export class PoApprovalsBrowserComponent {
//   /** Master grid data (Syncfusion expects {result, count}) */
//   // data: DataResult = { result: [], count: 0 };
//   poRows: PoHeaderView[] = [];

//   /** Dialog state */
//   detailHeader: PoHeaderView | null = null;
//   lines: PoLineView[] = [];
//   stages: PoStage[] = [];
//   dialogOpen = false;

//   @ViewChild('poDialog', { static: false }) poDialog?: DialogComponent;

//   constructor(private http: HttpClient) {}

//   ngOnInit() {
//     const params = new HttpParams().set('page', '1').set('pageSize', '20');
//     this.http.get<PoListResponse>('/api/po', { params }).subscribe((resp) => {
//       const rows = (resp?.rows ?? []).map(this.toHeader);
//       // this.data = { result: rows, count: resp?.total ?? rows.length };
//       this.poRows = rows;
//     });
//   }

//   // ---------- Normalizers ------------

//   private toHeader = (h: any): PoHeaderView => ({
//     poNumber: h.poNumber ?? h.PoNumber ?? '',
//     poDate: h.poDate ?? h.PoDate,
//     vendorName: h.vendorName ?? h.VendorName,
//     buyerName: h.buyerName ?? h.BuyerName,
//     houseCode: h.houseCode ?? h.HouseCode,
//     directAmount: h.directAmount ?? h.DirectAmount ?? 0,
//     indirectAmount: h.indirectAmount ?? h.IndirectAmount ?? 0,
//     totalAmount:
//       h.totalAmount ??
//       h.TotalAmount ??
//       (h.directAmount ?? h.DirectAmount ?? 0) +
//         (h.indirectAmount ?? h.IndirectAmount ?? 0),
//     status: (h.status ?? h.Status ?? 'W') as 'W' | 'A' | 'D',
//     isActive: (h.isActive ?? h.IsActive ?? true) as boolean,
//     createdAtUtc: h.createdAtUtc ?? h.CreatedAtUtc,
//     activeLineCount: h.activeLineCount ?? h.ActiveLineCount ?? 0,
//   });

//   private toLine = (l: any): PoLineView => ({
//     poNumber: l.poNumber ?? l.PoNumber ?? '',
//     lineNumber: l.lineNumber ?? l.LineNumber ?? 0,
//     itemNumber: l.itemNumber ?? l.ItemNumber ?? '',
//     itemDescription: l.itemDescription ?? l.ItemDescription,
//     specialDescription: l.specialDescription ?? l.SpecialDescription,
//     quantityOrdered: l.quantityOrdered ?? l.QuantityOrdered,
//     orderUom: l.orderUom ?? l.OrderUom,
//     unitCost: l.unitCost ?? l.UnitCost,
//     extendedCost: l.extendedCost ?? l.ExtendedCost,
//     requiredDate: l.requiredDate ?? l.RequiredDate,
//     glAccount: l.glAccount ?? l.GlAccount,
//     isActive: (l.isActive ?? l.IsActive ?? true) as boolean,
//   });

//   private toStage = (s: any): PoStage => ({
//     poNumber: s.poNumber ?? s.PoNumber ?? '',
//     sequence: s.sequence ?? s.Sequence ?? 0,
//     roleCode: s.roleCode ?? s.RoleCode ?? '',
//     approverUserId: s.approverUserId ?? s.ApproverUserId,
//     category: (s.category ?? s.Category ?? null) as 'I' | 'D' | null,
//     thresholdFrom: s.thresholdFrom ?? s.ThresholdFrom,
//     thresholdTo: s.thresholdTo ?? s.ThresholdTo,
//     status: (s.status ?? s.Status ?? 'P') as 'P' | 'A' | 'D' | 'S',
//     decidedAtUtc: s.decidedAtUtc ?? s.DecidedAtUtc,
//   });

//   // ----------------------- Events ------------------------------------------

//   onRowSelected(e: any) {
//     const row = e?.data;
//     const poNumber: string = row?.poNumber ?? row?.PoNumber ?? '';
//     if (!poNumber) return;

//     this.http
//       .get<PoDetailResponse>(`/api/po/${encodeURIComponent(poNumber)}`)
//       .subscribe((d) => {
//         this.detailHeader = this.toHeader(d?.header ?? row);
//         this.lines = (d?.lines ?? []).map(this.toLine);
//         this.stages = (d?.stages ?? []).map(this.toStage);
//         this.poDialog?.show();
//       });
//   }

//   onDlgOpen() {
//     this.dialogOpen = true;
//   }
//   onDlgClose() {
//     this.dialogOpen = false;
//   }

//   // Placeholders (wire later)
//   approve() {}
//   deny() {}
// }
