import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PoApprovalsHomeComponent } from './po-approvals-home.component';

describe('PoApprovalsHomeComponent', () => {
  let component: PoApprovalsHomeComponent;
  let fixture: ComponentFixture<PoApprovalsHomeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PoApprovalsHomeComponent]
    });
    fixture = TestBed.createComponent(PoApprovalsHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
